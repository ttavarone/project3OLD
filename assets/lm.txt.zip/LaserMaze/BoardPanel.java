import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * This creates the board and imports images representing the pieces.
 * It also controls how the general gameplay works, including mouseclicks
 * mousedrags, and other action objects.
 *
 * @version(4/5/18)
 */
public class BoardPanel extends JPanel implements MouseListener
{
    final private int windowWidth = 800;
    final private int windowHeight = 800;
    private int boardWidth = 600;
    private int boardHeight = 600;

    private int xCoord;
    private int yCoord;

    private Toolkit toolkit;
    private Image BlueQuestionMark;
    private Image BotLeftPurple;
    private Image BotRightPurple;
    private Image HorizontalYellow;
    private Image LaserBottom;
    private Image LaserRight;
    private Image PurpleQuestionMark;
    private Image TargetBottom;
    private Image TargetRight;
    private Image TopLeftBotRightBlue;
    private Image TopLeftPurple;
    private Image TopRightBotLeftBlue;
    private Image TopRightPurple;
    private Image VerticalYellow;


    public BoardPanel()
    {

        super();
        setOpaque(true);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(windowWidth,windowHeight));
        xCoord = 0;
        yCoord = 0;

        toolkit = Toolkit.getDefaultToolkit();

        BlueQuestionMark = toolkit.getImage("BlueQuestionMark.jpeg");
        BotLeftPurple = toolkit.getImage("GamePieces/BotLeftPurple.jpg");
        BotRightPurple = toolkit.getImage("GamePieces/BotRightPurple.jpg");
        HorizontalYellow = toolkit.getImage("GamePieces/HorizontalYellow.jpg");
        LaserBottom = toolkit.getImage("GamePieces/LaserBottom.jpg");
        LaserRight = toolkit.getImage("GamePieces/LaserRight.jpg");
        PurpleQuestionMark = toolkit.getImage("GamePieces/PurpleQuestionMark.jpg");
        TargetBottom = toolkit.getImage("GamePieces/TargetBottom.jpg");
        TargetRight = toolkit.getImage("GamePieces/TargetRight.jpg");
        TopLeftBotRightBlue = toolkit.getImage("GamePieces/TopLeftBotRightBlue.jpg");
        TopLeftPurple = toolkit.getImage("GamePieces/TopLeftPurple.jpg");
        TopRightBotLeftBlue = toolkit.getImage("GamePieces/TopRightBotLeftBlue.jpg");
        TopRightPurple = toolkit.getImage("GamePieces/TopRightPurple.jpg");
        VerticalYellow = toolkit.getImage("GamePieces/VerticalYellow.jpg");


        addMouseListener(this);
    }


    @Override
    public void paintComponent(Graphics g)
    {

        super.paintComponent(g);
        
        int sqDim = 120; //height and width dimensions of square

        //creating basic board square
        g.setColor(Color.BLACK);
        g.drawRoundRect(100, 100, boardWidth, boardHeight, 50, 50);
        g.setColor(Color.BLACK);
        g.drawRoundRect(90, 90, boardWidth+20, boardHeight+20, 50, 50);
        g.fillRoundRect(90, 90, boardWidth+20, boardHeight+20, 50, 50);
        g.setColor(Color.LIGHT_GRAY);
        g.fillRoundRect(100, 100, boardWidth, boardHeight, 50, 50);

        //create inner squares
        g.setColor(Color.BLACK);
        g.drawRect(100, 100, sqDim, sqDim);
        g.drawRect(100+sqDim, 100, sqDim, sqDim);
        g.drawRect(100+sqDim*2, 100, sqDim, sqDim);
        g.drawRect(100+sqDim*3, 100, sqDim, sqDim);
        g.drawRect(100+sqDim*4, 100, sqDim, sqDim);

        g.drawRect(100, 100+sqDim, sqDim, sqDim);
        g.drawRect(100+sqDim, 100+sqDim, sqDim, sqDim);
        g.drawRect(100+sqDim*2, 100+sqDim, sqDim, sqDim);
        g.drawRect(100+sqDim*3, 100+sqDim, sqDim, sqDim);
        g.drawRect(100+sqDim*4, 100+sqDim, sqDim, sqDim);

        g.drawRect(100, 100+sqDim*2, sqDim, sqDim);
        g.drawRect(100+sqDim, 100+sqDim*2, sqDim, sqDim);
        g.drawRect(100+sqDim*2, 100+sqDim*2, sqDim, sqDim);
        g.drawRect(100+sqDim*3, 100+sqDim*2, sqDim, sqDim);
        g.drawRect(100+sqDim*4, 100+sqDim*2, sqDim, sqDim);

        g.drawRect(100, 100+sqDim*3, sqDim, sqDim);
        g.drawRect(100+sqDim, 100+sqDim*3, sqDim, sqDim);
        g.drawRect(100+sqDim*2, 100+sqDim*3, sqDim, sqDim);
        g.drawRect(100+sqDim*3, 100+sqDim*3, sqDim, sqDim);
        g.drawRect(100+sqDim*4, 100+sqDim*3, sqDim, sqDim);

        g.drawRect(100, 100+sqDim*4, sqDim, sqDim);
        g.drawRect(100+sqDim, 100+sqDim*4, sqDim, sqDim);
        g.drawRect(100+sqDim*2, 100+sqDim*4, sqDim, sqDim);
        g.drawRect(100+sqDim*3, 100+sqDim*4, sqDim, sqDim);
        g.drawRect(100+sqDim*4, 100+sqDim*4, sqDim, sqDim);

        g.drawImage(toolkit.getImage("BlueQuestionMark.jpg"), xCoord, yCoord, this);


        //g.drawRect(xCoord, yCoord, 100, 100);
        //g.fillRect(xCoord, yCoord, 100, 100);
    }


    @Override
    public void mouseClicked(MouseEvent e) { //will need to select specific component before moving or drawing
        int button = e.getButton();

        xCoord = e.getX();
        yCoord = e.getY();

        repaint();
        e.consume();
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    
}

